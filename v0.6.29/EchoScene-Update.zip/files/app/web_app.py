"""ECHO web shell -- the Meta-style glass frontend (web_ui/) in a
pywebview window, bridged to the SAME backend the desktop shell
uses: app.py's module-level run_pipeline / run_depth_video /
list_previous_jobs / scene_file / replay_file, echo_app.settings
for persistence, echo_app.updater for updates, and the
echo_app.live_preview sequencer for the growing-scene preview.

Nothing here re-implements the pipeline. The bridge only moves
state between the page and those functions, with the same guards
as the desktop shell (one job at a time, validated video, outputs
only for jobs that have them).

Run:  python web_app.py           (needs pywebview; on Windows it
                                   rides the system WebView2)
"""
import base64
import io
import json
import os
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as backend  # the desktop shell's module-level backend
from echo_app import cli_events
from echo_app.settings import coerce_appearance, load_settings, save_settings
from echo_app.version import APP_VERSION

# 设置 → 显示： the page speaks camelCase, the settings file
# snake_case -- the same translation jobsRoot/updateProxy get,
# table-driven so the snapshot and the save path cannot drift.
_APPEARANCE_KEYS = [
    ("frostBlur", "frost_blur"), ("frostVeil", "frost_veil"),
    ("frostSaturate", "frost_saturate"), ("workHaze", "work_haze"),
    ("setBlur", "set_blur"), ("setVeil", "set_veil"),
    ("setSaturate", "set_saturate"), ("grafCount", "graf_count"),
    ("grafWidth", "graf_width"), ("grafOpacity", "graf_opacity"),
    ("grafSaturate", "graf_saturate"), ("mistDensity", "mist_density"),
    ("mistSize", "mist_size"), ("motionOn", "motion_on"),
    ("motionSpeed", "motion_speed"), ("motionAmp", "motion_amp"),
    ("sheenOn", "sheen_on"),
]


def _appearance_to_js(appearance):
    return {camel: getattr(appearance, snake)
            for camel, snake in _APPEARANCE_KEYS}


def _appearance_from_js(appearance, data):
    snake = {snake: data[camel] for camel, snake in _APPEARANCE_KEYS
             if isinstance(data, dict) and camel in data}
    return coerce_appearance(snake, base=appearance)

PLAIN_STATUS = backend.PLAIN_STATUS
STAGE_COUNT = backend.STAGE_COUNT
STAGE_ORDER = list(PLAIN_STATUS.keys())


def _open_folder(path: Path):
    if sys.platform.startswith("win"):
        subprocess.Popen(["explorer", str(path)])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def _find_blender_exe():
    """Locate blender.exe: PATH first, then the usual install spots.

    Windows only in practice (the desktop), but harmless elsewhere:
    off Windows only the PATH lookup runs. Returns the path as a
    string, or None when no Blender was found anywhere obvious.
    """
    import shutil

    found = shutil.which("blender") or shutil.which("blender.exe")
    if found:
        return found
    if not sys.platform.startswith("win"):
        return None
    roots = []
    for var in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        value = os.environ.get(var)
        if value:
            roots.append(Path(value))
    for root in roots:
        base = root / "Blender Foundation"
        for cand in sorted(base.glob("Blender */blender.exe")):
            if cand.is_file():
                return str(cand)
        plain = base / "Blender" / "blender.exe"
        if plain.is_file():
            return str(plain)
    steam = Path(os.environ.get("ProgramFiles(x86)", "")) / "Steam" \
        / "steamapps" / "common" / "Blender" / "blender.exe"
    if steam.is_file():
        return str(steam)
    return None


def _reveal_file(path: Path):
    """Show a file in the system file manager, selected if possible.

    Never raises: a failed reveal falls back to opening the folder,
    and a failed folder open is swallowed -- the caller reports the
    outcome through the status line and the log, not an exception.
    """
    path = Path(path)
    try:
        if sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select," + str(path)])
            return
    except Exception:
        pass
    try:
        _open_folder(path.parent)
    except Exception:
        pass


# Silent auto-check cadence (v0.6.29): ten minutes between checks.
AUTO_CHECK_SECONDS = 600.0


class Bridge:
    """State + actions exposed to the page as window.pywebview.api."""

    def __init__(self):
        self.settings = load_settings()
        try:
            from echo_app.updater import set_proxy
            set_proxy(self.settings.update_proxy)
        except Exception:
            pass
        self.jobs_root = self.settings.jobs_root_path()
        self.video = None            # Path of the selected video
        self.job = None              # Path of the current job
        self.busy = False
        self.busy_kind = None        # "scene" | "depth" | None
        self.status = "还没开始。"
        self.frac = 0.0
        self._stage_idx = 0
        self.depth_out = None        # Path of the last depth video
        self._pending_log = []
        self._all_log = []
        self._hist_sig = None
        self._maximized = False
        self._pre_max_rect = None  # window rect before a work-area
        # maximise, so restore can put it back where it was
        self._inbox_sig = None
        self._cli_cursor = cli_events.load_cursor()
        self._preview_seq = 0
        self._preview_data = None
        self._preview_stop = threading.Event()
        self._depth_stop = threading.Event()
        self._depth_stop.set()
        self._view = None
        self._toolbox = None         # cached toolbox payload (lazy)
        self.update = None           # {"version": str} when available
        # v0.6.29: the silent 10-minute auto-check + the async
        # manual check + the download progress the page shows live.
        self._check_lock = threading.Lock()
        self._auto_check_started = False
        self._auto_check_stop = threading.Event()
        self._manual_checking = False
        self._manual_check_seq = 0
        self._manual_check_result = None  # {"seq", "status", "version"}
        self._update_phase = None  # {"phase", "frac", "text"} or None
        self._window = None
        self._log("ECHO 已就绪。")
        # Hot-update housekeeping: report the last apply's outcome
        # once, and repair an interrupted one if it is still pending.
        try:
            from echo_app import hotupdate
            _root = hotupdate.install_root()
            hotupdate.recover(_root)
            _result = hotupdate.last_result(_root)
            if _result is not None:
                if _result.get("ok"):
                    self._log(f"热更新完成：已升级到 v{_result.get('version')}。")
                else:
                    self._log("上次热更新没成功，已经自动退回原来的版本。")
                (_root / ".echo" / "result.json").unlink(missing_ok=True)
        except Exception:
            pass

    # -- internal helpers -------------------------------------------
    def _log(self, line):
        self._all_log.append(line)
        del self._all_log[:-400]
        self._pending_log.append(line)

    def _pipeline_log(self, line):
        """run_pipeline's log callback: stage lines become the
        plain-language status + progress; everything is logged."""
        text = str(line)
        if text in PLAIN_STATUS:
            if text in STAGE_ORDER:
                self._stage_idx = max(self._stage_idx,
                                      STAGE_ORDER.index(text) + 1)
            self.status = PLAIN_STATUS[text] + "…"
            self.frac = self._stage_idx / STAGE_COUNT
        self._log(text)

    def _check_video(self, path: Path):
        if path.suffix.lower() not in backend.VIDEO_SUFFIXES:
            return "这个文件不是视频，换个视频文件试试。"
        if not path.exists():
            return "没找到这个视频文件。"
        return None

    def _history(self):
        out = []
        for job in backend.list_previous_jobs(self.jobs_root):
            try:
                when = time.strftime(
                    "%m-%d %H:%M", time.localtime(job.stat().st_mtime))
            except OSError:
                when = ""
            out.append({
                "name": backend._job_display_name(job),
                "dir": str(job),
                "finished": backend.job_finished(job),
                "when": when,
                "scale": backend.scale_status_line(job),
                "preview": (job / "preview.html").exists(),
                "replay": backend._replay_available(job),
            })
        return out

    # -- phone-capture inbox -----------------------------------------
    # The collector's captures sync themselves home (Syncthing)
    # into an "ECHO Captures" folder; the newest finished ones are
    # offered in the page, one click selects their video through
    # the same path as a drag-in. A capture counts as arrived only
    # when its meta says the phone finished it and no Syncthing
    # temp file remains -- a half-synced folder is never offered.
    @staticmethod
    def _inbox_roots():
        roots = []
        env = os.environ.get("ECHO_INBOX_DIR")
        if env:
            roots.append(Path(env))
        for letter in "CDEFG":
            roots.append(Path(f"{letter}:\\ECHO Captures"))
        roots.append(Path.home() / "ECHO Captures")
        return roots

    def _inbox(self):
        out = []
        for root in self._inbox_roots():
            try:
                if not root.is_dir():
                    continue
                for cap in root.glob("capture_*"):
                    if cap.is_dir():
                        entry = self._inbox_entry(cap)
                        if entry is not None:
                            out.append(entry)
            except OSError:
                continue
        out.sort(key=lambda e: e["mtime"], reverse=True)
        for entry in out:
            del entry["mtime"]
        return out

    @staticmethod
    def _inbox_entry(cap):
        video = cap / "video.mp4"
        if not video.exists():
            return None
        try:
            names = [p.name for p in cap.iterdir()]
        except OSError:
            return None
        if any(n.startswith(".syncthing") for n in names):
            return None
        meta = cap / "meta.json"
        if meta.exists():
            try:
                info = json.loads(meta.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return None
            if not info.get("finalized", False):
                return None
        try:
            total = sum(p.stat().st_size
                        for p in cap.rglob("*") if p.is_file())
            mtime = video.stat().st_mtime
        except OSError:
            return None
        return {
            "name": cap.name,
            "dir": str(cap),
            "video": str(video),
            "when": time.strftime("%m-%d %H:%M",
                                  time.localtime(mtime)),
            "mb": round(total / 1e6),
            "mtime": mtime,
        }

    def select_inbox_capture(self, dir_path):
        if self.busy:
            return {"ok": False, "message": "正在忙，先等这一件事做完。"}
        cap = Path(str(dir_path))
        try:
            parent = cap.resolve().parent
        except OSError:
            parent = None
        roots = []
        for root in self._inbox_roots():
            try:
                roots.append(root.resolve())
            except OSError:
                pass
        if parent is None or parent not in roots:
            return {"ok": False, "message": "这段采集不在收件夹里。"}
        if self._inbox_entry(cap) is None:
            return {"ok": False, "message": "这段采集还没传完。"}
        return self.select_video_path(cap / "video.mp4")

    # -- CLI activity (silent toasts) ---------------------------------
    # The headless CLI is a separate process; it leaves one JSON
    # line per finished command in the settings folder (see
    # echo_app.cli_events), and the page shows each as a one-line
    # silent toast -- the user's eyeball check that the CLI is
    # alive. The cursor (highest seq already handed to the page)
    # persists in the same folder, so a restart never replays old
    # news: the snapshot catches up only unpresented events from
    # the last ten minutes, while poll drains new ones as they
    # land. Events skipped as stale still advance the cursor.
    def _drain_cli_events(self, recent_only=False):
        try:
            events, hi = cli_events.read_since(self._cli_cursor)
            if hi > self._cli_cursor:
                self._cli_cursor = hi
                cli_events.save_cursor(hi)
            if recent_only:
                cutoff = time.time() - 600
                events = [e for e in events
                          if float(e.get("ts", 0)) >= cutoff]
            return [{"cmd": e.get("cmd"), "ok": bool(e.get("ok")),
                     "summary": e.get("summary", "")} for e in events]
        except Exception:
            return []

    # -- snapshot + polling ------------------------------------------
    def get_snapshot(self):
        hist = self._history()
        self._hist_sig = json.dumps(hist, ensure_ascii=False)
        inbox = self._inbox()
        self._inbox_sig = json.dumps(inbox, ensure_ascii=False)
        return {
            "version": APP_VERSION,
            "jobsRoot": str(self.jobs_root),
            "settings": {
                "autostart": self.settings.autostart,
                "closeToTray": self.settings.close_to_tray,
                "updateProxy": self.settings.update_proxy,
                "appearance": _appearance_to_js(self.settings.appearance),
                "windowMode": self.settings.window_mode,
            },
            "history": hist,
            "inbox": inbox,
            "status": self.status,
            "frac": self.frac,
            "busy": self.busy,
            "log": list(self._all_log),
            "cliEvents": self._drain_cli_events(recent_only=True),
        }

    def poll(self):
        out = {
            "status": self.status,
            "frac": self.frac,
            "busy": self.busy,
            "busyKind": self.busy_kind,
            "hasJob": self.job is not None,
            "depthReady": self.depth_out is not None,
            "logs": self._pending_log[:],
            "previewSeq": self._preview_seq,
            "update": self.update,
        }
        self._pending_log = []
        cli_new = self._drain_cli_events()
        if cli_new:
            out["cliEvents"] = cli_new
        hist = self._history()
        sig = json.dumps(hist, ensure_ascii=False)
        if sig != self._hist_sig:
            self._hist_sig = sig
            out["history"] = hist
        inbox = self._inbox()
        isig = json.dumps(inbox, ensure_ascii=False)
        if isig != self._inbox_sig:
            self._inbox_sig = isig
            out["inbox"] = inbox
        # v0.6.29: the preview frame used to ride every poll as a
        # full base64 PNG, twice a second for the whole depth job --
        # while the page never reads it (it watches previewSeq and
        # fetches the frame through get_preview_frame). That is the
        # main jank during a depth job; nothing is sent here any
        # more (get_preview_frame still serves the latest frame).
        if self._manual_check_result is not None:
            out["manualCheck"] = dict(self._manual_check_result)
        if self._update_phase is not None:
            out["updateProgress"] = dict(self._update_phase)
        if self.depth_out is not None:
            out["depthUrl"] = Path(self.depth_out).as_uri()
        if self.job is not None:
            # Real per-output availability, so the page lights only
            # the buttons whose file actually exists. (The page used
            # to light them all for any job, and clicks on a failed
            # job's buttons then silently did nothing.)
            job = Path(self.job)
            out["jobOutputs"] = {
                "any": job.exists(),
                "scene": backend.job_finished(job),
                "preview": (job / "preview.html").exists(),
                "replay": backend._replay_available(job),
            }
        return out

    def get_preview_frame(self):
        """The latest preview frame (data URL) + its sequence."""
        return {"seq": self._preview_seq, "data": self._preview_data}

    def get_toolbox(self):
        """The toolbox page's payload: every registered echo_super
        kernel, built live from the registry + VERSIONS.md by
        echo_app.toolbox (never a hand-kept list, so it cannot
        drift). Built once and cached -- assembling the registry
        imports the kernel packages."""
        if self._toolbox is None:
            try:
                from echo_app.toolbox import build_toolbox
                self._toolbox = build_toolbox()
            except Exception as exc:  # the page says so, shell lives
                self._log(f"工具箱清单读取失败：{exc}")
                return {"count": 0, "deployedCount": 0,
                        "groups": [], "error": str(exc)}
        return self._toolbox

    # -- selection ----------------------------------------------------
    def pick_video(self):
        if self.busy or self._window is None:
            return None
        import webview

        paths = self._window.create_file_dialog(
            webview.OPEN_DIALOG,
            allow_multiple=False,
            file_types=("视频 (*.mp4;*.mov;*.mkv;*.avi)",
                        "所有文件 (*.*)"))
        if paths:
            return self.select_video_path(paths[0])
        return None

    def select_video_path(self, path):
        if self.busy:
            return {"ok": False, "message": "正在忙，先等这一件事做完。"}
        p = Path(str(path))
        err = self._check_video(p)
        if err:
            self.status = err
            return {"ok": False, "message": err}
        self.video = p
        self.frac = 0.0  # v0.6.29: a finished depth job leaves the bar
        # full; a newly picked video starts from an empty bar.
        self.status = "视频选好了。点「开始生成」，或者做深度视频。"
        self._log(f"已选视频：{p.name}")
        return {"ok": True, "name": p.name}

    # -- jobs -----------------------------------------------------------
    def start_scene(self):
        if self.busy or self.video is None:
            return {"ok": False}
        err = self._check_video(self.video)
        if err:
            self.status = err
            return {"ok": False, "message": err}
        self.busy, self.busy_kind = True, "scene"
        self._stage_idx, self.frac = 0, 0.0
        self.status = "开始了。"
        threading.Thread(target=self._scene_worker, daemon=True).start()
        return {"ok": True}

    def _scene_worker(self):
        try:
            job = backend.run_pipeline(
                self.video, self.jobs_root, self._pipeline_log,
                job_sink=self._on_job_started)
            self.job = job
            self.status = "场景做好了。点「打开场景」就能看。"
            self.frac = 1.0
            scale = backend.scale_status_line(job)
            if scale:
                self._log(scale)
            self._log("场景生成完成。")
        except Exception:
            self.status = "生成失败，看一下日志。"
            self._log(traceback.format_exc(limit=2))
        finally:
            self.busy, self.busy_kind = False, None

    def start_depth(self):
        if self.busy or self.video is None:
            return {"ok": False}
        err = self._check_video(self.video)
        if err:
            self.status = err
            return {"ok": False, "message": err}
        self.busy, self.busy_kind = True, "depth"
        self.depth_out = None
        self.frac = 0.0
        self.status = "正在生成深度视频…"
        # The depth module lands its stills progressively in
        # <stem>_depth/ next to the output; watch them so the
        # preview screen (and the echo behind the glass) can show
        # the depth picture while it is still being made. The
        # output name mirrors run_depth_video's own choice -- one
        # job at a time, so the name cannot race.
        out = self.video.with_name(f"{self.video.stem}_depth.mp4")
        base, n = out, 1
        while out.exists():
            n += 1
            out = base.with_name(f"{base.stem}_{n}.mp4")
        self._depth_stop = threading.Event()
        threading.Thread(target=self._depth_stills_loop,
                         args=(out.parent / (out.stem + "_depth"),
                               self._depth_stop), daemon=True).start()
        threading.Thread(target=self._depth_worker, daemon=True).start()
        return {"ok": True}

    def _depth_stills_loop(self, stills_dir, stop):
        seen = None
        while not stop.is_set():
            try:
                stills = sorted(stills_dir.glob("d_*.png"))
                if stills:
                    newest = stills[-1]
                    size = newest.stat().st_size
                    if size and (newest.name, size) != seen:
                        seen = (newest.name, size)
                        data = newest.read_bytes()
                        self._preview_data = (
                            "data:image/png;base64,"
                            + base64.b64encode(data).decode())
                        self._preview_seq += 1
            except Exception:
                pass
            stop.wait(0.8)

    def _depth_worker(self):
        def _progress(stage, done, total):
            if total:
                # Extraction is quick; weight the bar to the depth
                # stage so it moves steadily through the long part.
                self.frac = (done / total) if stage != "frames" else 0.02
            if stage == "depth" and total:
                self.status = f"正在生成深度视频… {done}/{total}"
            elif stage == "encode":
                self.status = "正在合成深度视频…"

        try:
            self.depth_out = backend.run_depth_video(
                self.video, progress=_progress)
            self.status = "深度视频做好了。"
            self._log("深度视频完成。")
        except Exception:
            self.status = "深度视频生成失败，看一下日志。"
            self._log(traceback.format_exc(limit=2))
        finally:
            self._depth_stop.set()
            self.busy, self.busy_kind = False, None

    # -- outputs --------------------------------------------------------
    def _job_for(self, job_dir):
        if job_dir:
            p = Path(str(job_dir))
            if p.exists():
                return p
        return self.job

    def select_job(self, job_dir):
        job = self._job_for(job_dir)
        if job is not None:
            self.job = job
            self._start_preview(job)
        return {"ok": job is not None}

    def _open_target(self, target, what):
        """Open an output file, and NEVER fail silently: a missing
        file or a failed system open lands in the status line and
        the log, where the user can see what happened. (Silent
        no-ops here are what made the whole row of buttons look
        dead on 2026-11-02.)"""
        if target is not None and Path(target).exists():
            try:
                backend.play_file(Path(target))
                return {"ok": True}
            except Exception as exc:
                self.status = f"{what}打开失败，看一下日志。"
                self._log(f"{what}打开失败：{exc}")
                return {"ok": False}
        self.status = f"{what}还没有，暂时打不开。"
        self._log(f"{what}还没有，暂时打不开。")
        return {"ok": False}

    def open_scene(self, job_dir=None):
        job = self._job_for(job_dir)
        if job is None:
            return self._open_target(None, "场景")
        return self._open_target(backend.scene_file(job), "场景")

    def open_folder(self, job_dir=None):
        job = self._job_for(job_dir)
        if job is None or not Path(job).exists():
            return self._open_target(None, "任务文件夹")
        try:
            _open_folder(Path(job))
            return {"ok": True}
        except Exception as exc:
            self.status = "任务文件夹打开失败，看一下日志。"
            self._log(f"任务文件夹打开失败：{exc}")
            return {"ok": False}

    def open_preview_replay(self, job_dir=None):
        job = self._job_for(job_dir)
        if job is None:
            return self._open_target(None, "过程回放")
        return self._open_target(job / "preview.html", "过程回放")

    def open_route_replay(self, job_dir=None):
        job = self._job_for(job_dir)
        if job is None:
            return self._open_target(None, "路线回放")
        return self._open_target(backend.replay_file(job), "路线回放")

    def play_depth(self):
        if self.depth_out is None:
            return self._open_target(None, "深度视频")
        return self._open_target(Path(self.depth_out), "深度视频")

    # -- export ---------------------------------------------------------
    # A finished job's coloured solidified volume (voxel_color.glb +
    # voxel_color.ply) is the universal file: Blender opens it
    # natively, Three.js loads it with GLTFLoader. The three named
    # choices are one file under three names, exactly as the user
    # put it; "在 Blender 里打开" launches Blender with it. The
    # coloured export is built on demand from points.bin (the same
    # echo_scene.voxel_export the headless CLI's `export` uses), so
    # a job with no GLB yet is not a dead button -- it builds first.
    # Nothing here ever fails silently: a missing job, a missing
    # point cloud, a failed build, a missing Blender and a cancelled
    # folder pick all land in the status line and the log.
    def export_scene(self, job_dir=None, dest="general"):
        """Export the finished job. dest: "general" | "open-blender"
        (v0.6.28: "blender" / "threejs" were the same file under
        other names and are merged into "general"). The build runs
        on a worker thread; the folder pick for "general" happens
        here, on the bridge thread, like pick_jobs_root."""
        dest_dir = None
        if dest == "general":
            if self._window is None:
                self.status = "导出需要先选一个文件夹，窗口还没准备好。"
                self._log("导出通用格式：窗口还没准备好，稍后再试。")
                return {"ok": False}
            import webview

            paths = self._window.create_file_dialog(
                webview.FOLDER_DIALOG)
            if not paths:
                self.status = "已取消导出。"
                self._log("导出通用格式：已取消。")
                return {"ok": False}
            dest_dir = Path(paths[0])
        threading.Thread(
            target=self._run_export,
            args=(job_dir, dest, dest_dir), daemon=True).start()
        return {"ok": True}

    def _run_export(self, job_dir, dest, dest_dir):
        job = self._job_for(job_dir)
        if job is None:
            self.status = "没有选中的任务，先做完一个场景。"
            self._log("导出：没有选中的任务。")
            return
        job = Path(job)
        glb = job / "voxel_color.glb"
        ply = job / "voxel_color.ply"
        if not glb.exists() or not ply.exists():
            self.status = "正在固化导出文件…"
            self._log("导出：正在把场景固化成带颜色的体积文件…")
            try:
                from echo_scene.voxel_export import (
                    export_colored_voxels)
                info = export_colored_voxels(job)
            except Exception as exc:
                self.status = "导出失败，看一下日志。"
                self._log(f"导出固化失败：{exc}")
                return
            if not info.get("ok"):
                self.status = "这个任务还导不出，看一下日志。"
                self._log("导出固化失败："
                          f"{info.get('reason', '未知原因')}")
                return
            self._log(f"固化好了：{info.get('voxels', '?')} 个体素，"
                      f"{info.get('units', '')}")
        if dest == "open-blender":
            self._export_open_blender(job, glb)
        elif dest == "general":
            self._export_copy_out(job, glb, ply, dest_dir)
        else:
            # only "general" and "open-blender" remain (v0.6.28
            # dedup): a stale caller asking for another dest gets
            # an honest answer, not a file revealed as if the
            # export had happened.
            self.status = "导出方式不对，看一下日志。"
            self._log(f"导出：未知的导出方式 {dest!r}，"
                      "只支持通用文件和在 Blender 里打开。")

    def _export_copy_out(self, job, glb, ply, dest_dir):
        """"通用格式": copy the GLB + PLY (+ info) to a folder the
        user picked. Never raises; the outcome lands in the log."""
        import shutil

        try:
            dest_dir = Path(dest_dir)
            dest_dir.mkdir(parents=True, exist_ok=True)
            copied = []
            for src in (glb, ply, job / "voxel_color_info.json"):
                if src.exists():
                    shutil.copy2(src, dest_dir / src.name)
                    copied.append(src.name)
            if not copied:
                raise OSError("没有可复制的文件")
            self.status = f"已导出到 {dest_dir}"
            self._log("导出通用格式：已复制到 "
                      f"{dest_dir}：" + "、".join(copied))
        except Exception as exc:
            self.status = "导出失败，看一下日志。"
            self._log(f"导出通用格式失败：{exc}")

    def _export_open_blender(self, job, glb):
        """Launch Blender with the GLB. Blender imports a .glb
        passed on its command line; when no Blender is found the
        file is revealed instead, and the log says so plainly."""
        exe = _find_blender_exe()
        if exe is None:
            _reveal_file(glb)
            self.status = "没找到 Blender，文件已指给你看。"
            self._log("在 Blender 里打开：没找到 Blender（装一个就能"
                      "一键打开），文件已指给你看："
                      f"voxel_color.glb（{glb}）。")
            return
        try:
            subprocess.Popen([exe, str(glb)])
            self.status = "已在 Blender 里打开 voxel_color.glb"
            self._log(f"在 Blender 里打开：{glb}")
        except Exception as exc:
            _reveal_file(glb)
            self.status = "Blender 没打开，文件已指给你看。"
            self._log(f"在 Blender 里打开失败：{exc}，文件已指给你看："
                      f"{glb}。")

    def export_textured_mesh(self, job_dir=None):
        """Export the photo-textured mesh. The build (Poisson
        surface + per-view texturing + atlas) runs on a worker
        thread; a room job takes minutes, so the status line says
        so up front. Nothing fails silently."""
        threading.Thread(
            target=self._run_textured_export,
            args=(job_dir,), daemon=True).start()
        return {"ok": True}

    def _run_textured_export(self, job_dir):
        job = self._job_for(job_dir)
        if job is None:
            self.status = "没有选中的任务，先做完一个场景。"
            self._log("导出带贴图网格：没有选中的任务。")
            return
        job = Path(job)
        self.status = "正在生成带贴图网格，这要几分钟…"
        self._log("导出带贴图网格：开始生成（曲面重建 + 逐视角贴图）…")
        try:
            from echo_scene.voxel_export import export_textured_mesh
            info = export_textured_mesh(job, log=self._log)
        except Exception as exc:
            self.status = "导出失败，看一下日志。"
            self._log(f"导出带贴图网格失败：{exc}")
            return
        if not info.get("ok"):
            self.status = "这个任务还导不出带贴图网格，看一下日志。"
            self._log("导出带贴图网格失败："
                      f"{info.get('reason', '未知原因')}")
            return
        glb = Path(info["files"]["glb"])
        _reveal_file(glb)
        self.status = "导出好了：textured_mesh.glb（带贴图）"
        self._log(f"导出带贴图网格：{info.get('triangles', '?')} 个三角形，"
                  f"{info.get('views_used', '?')} 个视角，"
                  f"{info.get('untextured_triangles', 0)} 个三角形没拍到。"
                  f"文件：{glb}")

    def export_camera_route(self, job_dir=None):
        """Export the recovered camera route. The build (poses ->
        route JSON + GLB) runs on a worker thread; it is quick --
        no reconstruction -- but the thread keeps the UI honest
        all the same. Nothing fails silently."""
        threading.Thread(
            target=self._run_route_export,
            args=(job_dir,), daemon=True).start()
        return {"ok": True}

    def _run_route_export(self, job_dir):
        job = self._job_for(job_dir)
        if job is None:
            self.status = "没有选中的任务，先做完一个场景。"
            self._log("导出相机路线：没有选中的任务。")
            return
        job = Path(job)
        self.status = "正在导出相机路线…"
        self._log("导出相机路线：开始（相机位姿 → 路线文件）…")
        try:
            from echo_scene.voxel_export import export_camera_route
            info = export_camera_route(job, log=self._log)
        except Exception as exc:
            self.status = "导出失败，看一下日志。"
            self._log(f"导出相机路线失败：{exc}")
            return
        if not info.get("ok"):
            self.status = "这个任务还导不出相机路线，看一下日志。"
            self._log("导出相机路线失败："
                      f"{info.get('reason', '未知原因')}")
            return
        glb = Path(info["files"]["glb"])
        _reveal_file(glb)
        self.status = "导出好了：camera_route.glb + camera_route.json"
        self._log(f"导出相机路线：{info.get('frame_count', '?')} 帧，"
                  f"路线 {info.get('route_length', 0):.2f} "
                  f"{info.get('units', '')}，"
                  f"{info.get('skipped_frames', 0)} 帧跳过。"
                  f"文件：{glb}，{info['files']['json']}")

    def export_batch(self, job_dirs=None, dest_dir=None):
        """Export several finished jobs in one run. job_dirs:
        the job folders the user ticked in the history list. The
        output folder is picked here, on the bridge thread, like
        the "general" export's folder pick; the build itself runs
        on a worker thread. Nothing fails silently."""
        jobs = [str(d) for d in (job_dirs or []) if d]
        if not jobs:
            self.status = "先在历史场景里勾上要导出的任务。"
            self._log("批量导出：一个任务都没勾上。")
            return {"ok": False}
        if dest_dir is None:
            if self._window is None:
                self.status = "导出需要先选一个文件夹，窗口还没准备好。"
                self._log("批量导出：窗口还没准备好，稍后再试。")
                return {"ok": False}
            import webview

            paths = self._window.create_file_dialog(
                webview.FOLDER_DIALOG)
            if not paths:
                self.status = "已取消批量导出。"
                self._log("批量导出：已取消。")
                return {"ok": False}
            dest_dir = Path(paths[0])
        threading.Thread(
            target=self._run_batch_export,
            args=(jobs, dest_dir), daemon=True).start()
        return {"ok": True}

    def _run_batch_export(self, job_dirs, dest_dir):
        dest_dir = Path(dest_dir)
        self.status = f"正在批量导出 {len(job_dirs)} 个任务…"
        self._log(f"批量导出：开始，{len(job_dirs)} 个任务，"
                  f"文件夹：{dest_dir}")
        try:
            from echo_scene.voxel_export import export_batch
            info = export_batch(job_dirs, dest_dir, log=self._log)
        except Exception as exc:
            self.status = "批量导出失败，看一下日志。"
            self._log(f"批量导出失败：{exc}")
            return
        if not info.get("ok"):
            self.status = "批量导出失败，看一下日志。"
            self._log("批量导出失败："
                      f"{info.get('reason', '未知原因')}")
            return
        done = info.get("exported", 0)
        skipped = info.get("skipped", 0)
        summary = dest_dir / "batch_export.json"
        if summary.exists():
            _reveal_file(summary)
        if skipped:
            self.status = (f"批量导出好了：{done} 个任务，"
                           f"{skipped} 个跳过，看一下日志。")
        else:
            self.status = f"批量导出好了：{done} 个任务。"
        self._log(f"批量导出：{done} 个任务导好了，{skipped} 个跳过。"
                  f"文件夹：{dest_dir}，汇总：batch_export.json")

    # -- live preview -----------------------------------------------------
    def _on_job_started(self, job):
        self.job = job
        self._start_preview(job)

    def _start_preview(self, job):
        self._preview_stop.set()
        self._preview_stop = threading.Event()
        stop = self._preview_stop
        threading.Thread(target=self._preview_loop, args=(job, stop),
                         daemon=True).start()

    def _preview_loop(self, job, stop):
        """Same watcher/sequencer loop as the desktop shell; frames
        leave as PNG data URLs for the page's preview canvas.
        Optional subsystem: it can never take a job down."""
        try:
            from PIL import Image

            from echo_app.live_preview import (JobWatcher, LiveSequencer,
                                               ViewState, render_snapshot)
            if self._view is None:
                self._view = ViewState()
            watcher = JobWatcher(job, stable_polls=2)
            seq = LiveSequencer(job, view=self._view)
            last_signature, last_render = None, 0.0
            while not stop.is_set():
                events = watcher.poll()
                if events:
                    seq.consume(events)
                view = self._view
                signature = (seq.state.phase, seq.state.frames_seen,
                             len(seq.state.reliefs),
                             seq.state.settled is not None,
                             view.version if view is not None else 0)
                now = time.monotonic()
                if signature != last_signature or now - last_render > 3.0:
                    img, _dt = render_snapshot(seq, width=880, height=520)
                    frame = Image.fromarray(img)
                    buf = io.BytesIO()
                    frame.save(buf, format="PNG")
                    self._preview_data = (
                        "data:image/png;base64,"
                        + base64.b64encode(buf.getvalue()).decode())
                    self._preview_seq += 1
                    last_render, last_signature = now, signature
                stop.wait(0.7)
        except Exception:
            pass

    def preview_drag(self, dx, dy, pan=False):
        if self._view is not None:
            if pan:
                self._view.pan_drag(float(dx), float(dy))
            else:
                self._view.drag(float(dx), float(dy))
        return {"ok": True}

    def preview_zoom(self, steps):
        if self._view is not None:
            self._view.zoom(float(steps))
        return {"ok": True}

    def preview_reset(self):
        if self._view is not None:
            self._view.reset()
        return {"ok": True}

    # -- settings + updates ----------------------------------------------
    def save_settings(self, data):
        try:
            if "jobsRoot" in data and data["jobsRoot"]:
                self.settings.jobs_root = str(data["jobsRoot"])
                self.jobs_root = self.settings.jobs_root_path()
                self._hist_sig = None
            if "autostart" in data:
                self.settings.autostart = bool(data["autostart"])
                try:
                    from echo_app.autostart import set_autostart
                    set_autostart(self.settings.autostart)
                except Exception:
                    pass
            if "closeToTray" in data:
                self.settings.close_to_tray = bool(data["closeToTray"])
            if "updateProxy" in data:
                self.settings.update_proxy = str(data["updateProxy"]).strip()
                try:
                    from echo_app.updater import set_proxy
                    set_proxy(self.settings.update_proxy)
                except Exception:
                    pass
            if "windowMode" in data:
                mode = str(data["windowMode"])
                if mode in ("windowed", "borderless", "fullscreen"):
                    self.settings.window_mode = mode
            if "appearance" in data:
                self.settings.appearance = _appearance_from_js(
                    self.settings.appearance, data["appearance"])
            save_settings(self.settings)
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    def pick_jobs_root(self):
        if self._window is None:
            return None
        import webview

        paths = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        return paths[0] if paths else None

    def check_update(self):
        """Startup check + start the silent 10-minute auto-check
        loop (v0.6.29): the loop re-checks every ten minutes and
        stays silent unless the check cannot reach the update
        source at all -- _run_check logs only that failure (and a
        found update); a reachable source with no new version logs
        nothing. The manual button keeps its v0.6.25 behaviour
        (re-check on click, always answer)."""
        if not self._auto_check_started:
            self._auto_check_started = True
            threading.Thread(target=self._auto_check_loop,
                             daemon=True).start()
        threading.Thread(target=lambda: self._run_check(False),
                         daemon=True).start()
        return {"ok": True}

    def _auto_check_loop(self):
        while not self._auto_check_stop.is_set():
            self._auto_check_stop.wait(AUTO_CHECK_SECONDS)
            if self._auto_check_stop.is_set():
                break
            self._run_check(False)

    def manual_check_update(self):
        """The settings-page check, now off the UI thread (v0.6.29):
        the old synchronous call ran the whole route probe on the
        bridge thread -- up to ~30 s of frozen window -- before
        answering. This returns at once; the answer lands in poll()
        as manualCheck (with a sequence number) and the page
        renders the note from there."""
        if getattr(self, "_manual_checking", False):
            return {"ok": True, "checking": True}
        self._manual_checking = True
        threading.Thread(target=self._manual_check_worker,
                         daemon=True).start()
        return {"ok": True, "checking": True}

    def _manual_check_worker(self):
        try:
            result = self._run_check(True)
        except Exception:
            result = {"status": "error"}
        finally:
            self._manual_checking = False
        self._manual_check_seq += 1
        self._manual_check_result = {"seq": self._manual_check_seq,
                                     **result}

    def _run_check(self, manual):
        # One check at a time (v0.6.29): the 10-minute loop, the
        # 90-second startup retry and a manual check can otherwise
        # pile up on the same slow route probe.
        with self._check_lock:
            return self._run_check_locked(manual)

    def _run_check_locked(self, manual):
        try:
            from echo_app import updater
            from echo_app.updater import (check_for_update_status,
                                          fetch_releases, pick_hop)
            # The relay first: a static mirror with no API quota.
            # Only when it cannot answer do we spend GitHub API
            # calls (whose shared-IP rate limit kept locking the
            # user out with a misleading "cannot connect").
            status = info = hop_release = None
            try:
                plan = updater.relay_plan(
                    APP_VERSION, updater.fetch_relay_index())
            except Exception:
                plan = None
            if plan is not None:
                status, info, hop_release = plan
            else:
                status, info = check_for_update_status(APP_VERSION)
            if status != "error":
                # A probed local proxy answered: keep it, so no one
                # ever has to set anything for updates again.
                try:
                    found = updater.auto_proxy()
                    if found and not self.settings.update_proxy:
                        self.settings.update_proxy = found
                        save_settings(self.settings)
                        updater.set_proxy(found)
                        self._log("已自动找到能连上 GitHub 的本机代理"
                                  f"（{found}），以后的更新都走它，"
                                  "不用你管。")
                except Exception:
                    pass
            if status == "update" and info is not None:
                self.update = {"version": info.version}
                self._update_info = info
                self._log(f"有新版本：{info.version}")
                # Prefer the hot path, megabytes instead of the full
                # installer. Packs are chained, so aim at the NEXT
                # release above this one, not blindly at the latest:
                # a client several versions behind climbs one hop,
                # relaunches, and the next check climbs the next.
                try:
                    from echo_app import hotupdate
                    hop = hop_release
                    if hop is None:
                        hop = pick_hop(fetch_releases(), APP_VERSION)
                    if hop is not None:
                        hot = hotupdate.check_hot_update(
                            hop, hotupdate.install_root())
                        if hot is not None:
                            self._hot_info = hot
                            self.update = {
                                "version": hot.version, "hot": True,
                                "mb": round(hot.total_bytes / 1e6, 1)}
                            self._log("这个版本可以热更新，"
                                      f"只需下载约 {self.update['mb']} MB。")
                except Exception:
                    pass
                return {"status": "update", "version": info.version}
            if status == "error":
                # Never silent again: the log is where a failed check
                # explains itself -- and by now every route was tried.
                self._log("更新检查没连上：直连和本机常见代理端口都"
                          "试过了，还是到不了 GitHub。可以到发布页"
                          "手动更新，或在设置里填你自己的代理地址。")
                if not manual and not getattr(self, "_check_retried",
                                              False):
                    self._check_retried = True
                    self._retry_timer = threading.Timer(
                        90.0, lambda: self._run_check(False))
                    self._retry_timer.daemon = True
                    self._retry_timer.start()
                return {"status": "error"}
            return {"status": "latest"}
        except Exception:
            return {"status": "error"}

    def _set_update_progress(self, phase, frac=None, text=""):
        """Download/apply progress for the page (v0.6.29): phase in
        {"downloading", "staging", "applying", "restarting",
        "done", "failed"}; frac 0..1 when the download knows its
        total, else None (the page animates the bar
        indeterminately, so there is always visible motion)."""
        self._update_phase = {"phase": phase, "frac": frac, "text": text}

    def download_update(self):
        hot = getattr(self, "_hot_info", None)
        if hot is not None:
            def _hot():
                try:
                    import subprocess

                    from echo_app import hotupdate
                    root = hotupdate.install_root()
                    self._set_update_progress(
                        "downloading", 0.0, "正在下载更新…")
                    hotupdate.download_and_stage(
                        root, hot, progress=lambda done, total:
                        self._set_update_progress(
                            "downloading",
                            (done / total) if total else None,
                            "正在下载更新… "
                            f"{round(done / 1e6, 1)} MB"
                            + (f" / 约 {round(total / 1e6, 1)} MB"
                               if total else "")))
                    self._set_update_progress(
                        "applying", None, "正在应用更新…")
                    cmd = hotupdate.request_apply(root, hot)
                    self._set_update_progress(
                        "restarting", None, "正在重启完成更新…")
                    self._log("更新已备好，正在重启完成更新…")
                    subprocess.Popen(cmd, close_fds=True)
                    threading.Timer(0.4, self._quit).start()
                except Exception:
                    self._hot_info = None
                    self._set_update_progress(
                        "failed", None, "热更新没成，改走完整安装包。")
                    self._log("热更新没成，改走完整安装包。")
                    # Let the failure show for a beat before the
                    # fallback starts: otherwise the installer
                    # download begins at once and the user never
                    # sees why a small update became a big one.
                    # This is the worker thread, never the UI.
                    time.sleep(1.2)
                    self.download_update()
            threading.Thread(target=_hot, daemon=True).start()
            return {"ok": True}
        info = getattr(self, "_update_info", None)
        if info is None:
            # No stored result: the startup check ran before any
            # newer release existed (or never ran at all).
            # Re-check now in the background instead of answering
            # silently -- this button must always say what happened.
            if getattr(self, "_update_checking", False):
                return {"ok": True}

            def _recheck():
                try:
                    self.status = "正在检查更新…"
                    self._log("正在重新检查更新…")
                    result = self._run_check(True)
                    if getattr(self, "_hot_info", None) is not None \
                            or getattr(self, "_update_info", None) is not None:
                        self.download_update()
                        return
                    if result.get("status") == "latest":
                        self.status = "已经是最新版本。"
                        self._log("已经是最新版本。")
                    else:
                        self.status = "更新检查没连上，看一下日志。"
                finally:
                    self._update_checking = False

            self._update_checking = True
            threading.Thread(target=_recheck, daemon=True).start()
            return {"ok": True}

        def _download():
            try:
                from echo_app.updater import download_installer
                self._set_update_progress(
                    "downloading", 0.0, "正在下载安装包…")
                dest = download_installer(
                    info, self.jobs_root,
                    progress=lambda done, total:
                    self._set_update_progress(
                        "downloading",
                        (done / total) if total else None,
                        "正在下载安装包… "
                        f"{round(done / 1e6)} MB"
                        + (f" / 约 {round(total / 1e6)} MB"
                           if total else "")))
                self._set_update_progress(
                    "done", 1.0, "新版本安装包已下载，正在打开。")
                self._log("新版本安装包已下载，正在打开。")
                backend.play_file(Path(dest))
            except Exception:
                self._set_update_progress(
                    "failed", None, "更新下载失败，看一下日志。")
                self._log("更新下载失败。")
        threading.Thread(target=_download, daemon=True).start()
        return {"ok": True}

    def _quit(self):
        try:
            if self._window is not None:
                self._window.destroy()
        except Exception:
            pass
        import os
        os._exit(0)

    # -- window controls (the window is frameless; the page carries
    # its own caption buttons in the same glass language) --------------
    def win_minimize(self):
        try:
            if self._window is not None:
                self._window.minimize()
        except Exception:
            pass
        return {"ok": True}

    def _window_hwnd(self):
        """The native window handle, same route _polish_window uses."""
        window = self._window
        if window is None:
            return None
        try:
            native = getattr(window, "native", None)
            if native is not None:
                return int(native.Handle)
        except Exception:
            pass
        try:
            import ctypes

            return ctypes.windll.user32.FindWindowW(
                None, "ECHO 回声") or None
        except Exception:
            return None

    def _maximize_work_area(self):
        """Fill the monitor's work area (taskbar stays visible).

        pywebview's maximize() on a frameless window does not fill
        the screen on Windows, so do it the way Windows itself does:
        SetWindowPos to the work area of the monitor the window sits
        on. Returns True on success. Any failure is silent -- the
        caller falls back to the plain maximise()."""
        if sys.platform != "win32":
            return False
        try:
            import ctypes
            from ctypes import wintypes

            hwnd = self._window_hwnd()
            if not hwnd:
                return False
            user32 = ctypes.windll.user32
            # save the rect so restore can put the window back
            rect = wintypes.RECT()
            if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                return False
            self._pre_max_rect = (rect.left, rect.top,
                                  rect.right - rect.left,
                                  rect.bottom - rect.top)
            # the work area of the monitor this window is on
            MONITOR_DEFAULTTONEAREST = 2
            hmon = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)

            class MONITORINFO(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD),
                            ("rcMonitor", wintypes.RECT),
                            ("rcWork", wintypes.RECT),
                            ("dwFlags", wintypes.DWORD)]

            mi = MONITORINFO()
            mi.cbSize = ctypes.sizeof(MONITORINFO)
            if hmon and user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
                work = mi.rcWork
            else:  # primary monitor's work area
                work = wintypes.RECT()
                SPI_GETWORKAREA = 0x0030
                if not user32.SystemParametersInfoW(
                        SPI_GETWORKAREA, 0, ctypes.byref(work), 0):
                    return False
            SWP_NOZORDER = 0x0004
            SWP_SHOWWINDOW = 0x0040
            return bool(user32.SetWindowPos(
                hwnd, 0, work.left, work.top,
                work.right - work.left, work.bottom - work.top,
                SWP_NOZORDER | SWP_SHOWWINDOW))
        except Exception:
            return False

    def _restore_work_area(self):
        """Undo _maximize_work_area: back to the saved rect."""
        if sys.platform != "win32":
            return False
        try:
            import ctypes

            rect = getattr(self, "_pre_max_rect", None)
            hwnd = self._window_hwnd()
            if not rect or not hwnd:
                return False
            user32 = ctypes.windll.user32
            SWP_NOZORDER = 0x0004
            SWP_SHOWWINDOW = 0x0040
            return bool(user32.SetWindowPos(
                hwnd, 0, rect[0], rect[1], rect[2], rect[3],
                SWP_NOZORDER | SWP_SHOWWINDOW))
        except Exception:
            return False

    def win_toggle_max(self):
        # "borderless" (the default) is the one the user asked for:
        # maximise the frameless window to the work area, taskbar
        # stays visible -- NOT a video fullscreen. "windowed" is
        # the plain maximise; "fullscreen" never reaches here, the
        # page routes it to the DOM fullscreen API instead.
        mode = getattr(self.settings, "window_mode", "borderless")
        try:
            if self._window is not None:
                if getattr(self, "_maximized", False):
                    if mode == "borderless":
                        if not self._restore_work_area():
                            self._window.restore()
                    else:
                        self._window.restore()
                    self._maximized = False
                else:
                    if mode == "borderless":
                        if not self._maximize_work_area():
                            self._window.maximize()
                    else:
                        self._window.maximize()
                    self._maximized = True
        except Exception:
            pass
        return {"ok": True}

    def win_close(self):
        self._quit()
        return {"ok": True}


# ================= CHROME-LIKE RESIZE (v0.6.28) =================
# A frameless window has no frame for Windows to grab, so out of
# the box it cannot be resized by dragging an edge or a corner --
# the one thing Chrome does that this window did not. The fix is
# the same one every frameless Win32 window uses: answer
# WM_NCHITTEST with the resize hit codes for a border band
# (HTLEFT / HTRIGHT / HTTOP / HTBOTTOM and the four corners).
# Windows then runs the resize drag itself -- no Python code runs
# during the drag, so it tracks the cursor exactly like Chrome,
# including the diagonal corner.
#
# The hook subclasses the window procedure, installed the same way
# _polish_window is (at start, on shown, and on two delayed timers,
# since the native handle may not exist at first call), and chained
# to whatever procedure was there before, so pywebview's own
# handling is untouched. Windows-only, fully guarded: a failure to
# install costs nothing -- the window simply keeps its old
# behaviour. The pure geometry (_hit_test_resize) is factored out
# so it can be unit-tested on any platform; the Win32 half cannot
# run on this Linux VM and is verified by code review only, and
# needs a real-desktop check.
#
# When the window fills its frame -- the monitor work area (the
# borderless-maximized mode) or the whole monitor (fullscreen) --
# the border band stops offering resize, exactly like a maximized
# Chrome window: restore first, then drag. The check is stateless
# (window rect vs the monitor's work/full rects), so it stays true
# no matter which path maximized the window.
# ------------------------------------------------------------------
_RESIZE_BORDER = 8  # px: the band at each edge that grabs a resize

_HTCLIENT = 1
_HTLEFT = 10
_HTRIGHT = 11
_HTTOP = 12
_HTTOPLEFT = 13
_HTTOPRIGHT = 14
_HTBOTTOM = 15
_HTBOTTOMLEFT = 16
_HTBOTTOMRIGHT = 17

_WM_NCHITTEST = 0x0084
_GWLP_WNDPROC = -4

# the subclass chain: the previous procedure (an address) and the
# callback object, which MUST stay alive in this module -- if it is
# garbage-collected, the next WM_NCHITTEST crashes the process.
_resize_orig_proc = None
_resize_hook_hwnd = None
_resize_callback = None
_resize_argtypes_set = False


def _hit_test_resize(x, y, rect, border=_RESIZE_BORDER, frames=()):
    """Pure geometry: the resize hit code for a cursor at (x, y) in
    screen pixels against window rect (left, top, right, bottom).
    frames are the rects the window fills when it must NOT resize
    (monitor work area / full monitor); when the window fills one
    of them, or the cursor is not in the border band, HTCLIENT."""
    left, top, right, bottom = rect
    for frame in frames:
        fl, ft, fr, fb = frame
        if (abs(left - fl) <= 2 and abs(top - ft) <= 2
                and abs(right - fr) <= 2 and abs(bottom - fb) <= 2):
            return _HTCLIENT
    at_left = x < left + border
    at_right = x >= right - border
    at_top = y < top + border
    at_bottom = y >= bottom - border
    if at_top and at_left:
        return _HTTOPLEFT
    if at_top and at_right:
        return _HTTOPRIGHT
    if at_bottom and at_left:
        return _HTBOTTOMLEFT
    if at_bottom and at_right:
        return _HTBOTTOMRIGHT
    if at_left:
        return _HTLEFT
    if at_right:
        return _HTRIGHT
    if at_top:
        return _HTTOP
    if at_bottom:
        return _HTBOTTOM
    return _HTCLIENT


def _signed_short(v):
    """Low/high word of lParam as a signed 16-bit value (screen
    coordinates go negative on monitors left/above the primary)."""
    import ctypes

    return ctypes.c_short(v & 0xFFFF).value


def _window_frame_rects(hwnd):
    """(work area, full monitor) for the monitor the window sits on,
    as (left, top, right, bottom) tuples. None on any failure --
    the caller then treats the window as resizable."""
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        MONITOR_DEFAULTTONEAREST = 2
        hmon = user32.MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST)

        class MONITORINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD),
                        ("rcMonitor", wintypes.RECT),
                        ("rcWork", wintypes.RECT),
                        ("dwFlags", wintypes.DWORD)]

        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        if hmon and user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
            work = mi.rcWork
            mon = mi.rcMonitor
            return ((work.left, work.top, work.right, work.bottom),
                    (mon.left, mon.top, mon.right, mon.bottom))
    except Exception:
        pass
    return None


def _win32_argtypes(user32, wndproc_type, set_long):
    """Pin the ctypes signatures for the user32 calls the hook
    makes. Without argtypes, ctypes passes Python ints as 32-bit
    C ints -- on 64-bit Windows that truncates the previous
    procedure's address when it is handed back to CallWindowProcW.
    Set once, guarded, best effort."""
    global _resize_argtypes_set
    if _resize_argtypes_set:
        return
    try:
        import ctypes
        from ctypes import wintypes

        user32.CallWindowProcW.argtypes = [
            wndproc_type, wintypes.HWND, wintypes.UINT,
            wintypes.WPARAM, wintypes.LPARAM]
        user32.CallWindowProcW.restype = ctypes.c_ssize_t
        set_long.argtypes = [
            wintypes.HWND, ctypes.c_int, wndproc_type]
        set_long.restype = ctypes.c_void_p
        user32.GetWindowRect.argtypes = [
            wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.GetWindowRect.restype = wintypes.BOOL
        _resize_argtypes_set = True
    except Exception:
        pass


def _resize_wndproc(hwnd, msg, wparam, lparam):
    if msg == _WM_NCHITTEST:
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            x = _signed_short(lparam & 0xFFFF)
            y = _signed_short((lparam >> 16) & 0xFFFF)
            rect = wintypes.RECT()
            if user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                frames = _window_frame_rects(hwnd) or ()
                code = _hit_test_resize(
                    x, y,
                    (rect.left, rect.top, rect.right, rect.bottom),
                    frames=frames)
                if code != _HTCLIENT:
                    return code
        except Exception:
            pass
    # every other message, and every hit-test inside the band's
    # inner edge, goes to the procedure that was there before --
    # pywebview's handling is untouched. If the chain was never
    # installed (only possible for a message racing the swap),
    # HTCLIENT is the safe answer: the cursor is over the page.
    orig = _resize_orig_proc
    if orig is None:
        return _HTCLIENT
    return ctypes.windll.user32.CallWindowProcW(
        orig, hwnd, msg, wparam, lparam)


def _install_resize_hook(window):
    """Subclass the native window procedure so WM_NCHITTEST answers
    resize hit codes on the border band. Idempotent per handle;
    Windows-only; any failure is silent -- the window keeps
    working, it just cannot be resized by dragging an edge."""
    global _resize_orig_proc, _resize_hook_hwnd, _resize_callback
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        from ctypes import wintypes

        hwnd = None
        native = getattr(window, "native", None)
        if native is not None:
            try:
                hwnd = int(native.Handle)
            except Exception:
                hwnd = None
        if not hwnd:
            try:
                hwnd = ctypes.windll.user32.FindWindowW(
                    None, "ECHO 回声") or None
            except Exception:
                hwnd = None
        if not hwnd:
            return False
        if _resize_hook_hwnd == hwnd and _resize_callback is not None:
            return True  # already installed on this handle
        user32 = ctypes.windll.user32
        wndproc_type = ctypes.WINFUNCTYPE(
            ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
            wintypes.WPARAM, wintypes.LPARAM)
        set_long = (getattr(user32, "SetWindowLongPtrW", None)
                    or getattr(user32, "SetWindowLongW", None))
        if set_long is None:
            return False
        _win32_argtypes(user32, wndproc_type, set_long)
        _resize_callback = wndproc_type(_resize_wndproc)
        prev = set_long(hwnd, _GWLP_WNDPROC, _resize_callback)
        if not prev:
            _resize_callback = None
            return False
        _resize_orig_proc = prev
        _resize_hook_hwnd = hwnd
        return True
    except Exception:
        return False


def _polish_and_hook(window):
    """Both native treatments, at every moment the handle may
    exist: the DWM polish and the Chrome-like resize hook."""
    _polish_window(window)
    _install_resize_hook(window)
# ================= END CHROME-LIKE RESIZE (v0.6.28) =================


def _polish_window(window):
    """Win11 window treatments, best effort: rounded corners and a
    caption bar wearing the app's own pale tint, so the frame stops
    looking like a stranger around the page. Windows-only and fully
    guarded -- a failure here must never cost a launch."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        native = getattr(window, "native", None)
        hwnd = None
        if native is not None:
            try:
                hwnd = int(native.Handle)
            except Exception:
                hwnd = None
        if not hwnd:
            try:  # the native handle may not exist yet at first call
                hwnd = ctypes.windll.user32.FindWindowW(
                    None, "ECHO 回声") or None
            except Exception:
                hwnd = None
        if not hwnd:
            return
        dwm = ctypes.windll.dwmapi

        def _set(attr, value):
            v = ctypes.c_int(value)
            dwm.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(v), ctypes.sizeof(v))

        _set(20, 0)         # immersive dark caption: off (light glass)
        _set(33, 2)         # corner preference: round (the Win11 look)
        _set(35, 0xF7F2EE)  # caption colour: our pale glass #eef2f7 (BGR)
        _set(36, 0x211E1C)  # caption text: our ink #1c1e21 (BGR)
    except Exception:
        pass


def main():
    import webview

    if sys.platform == "win32":
        try:  # per-monitor DPI awareness: crisp text on scaled displays
            import ctypes

            ctypes.windll.user32.SetProcessDpiAwarenessContext(
                ctypes.c_void_p(-4))
        except Exception:
            pass

    bridge = Bridge()
    try:  # say once, in the log, where depth compute will run
        import onnxruntime as _ort

        _provs = _ort.get_available_providers()
        if ("DmlExecutionProvider" in _provs
                or "CUDAExecutionProvider" in _provs):
            bridge._log("显卡加速可用，深度计算会走显卡。")
        else:
            bridge._log("深度计算使用 CPU（未检测到显卡运行时）。")
    except Exception:
        pass
    # The page ships in the loose payload: resolve it next to this
    # file first (that is the copy hot updates replace), and only
    # fall back to the frozen resource path in a source tree.
    _here = Path(__file__).resolve().parent / "web_ui" / "index.html"
    index = _here if _here.exists() else backend._resource_path(
        "web_ui/index.html")
    # easy_drag stays OFF: pywebview's easy drag arms a window move
    # on *every* mousedown anywhere in the page, which ate the
    # settings sliders alive (the window chased the cursor out from
    # under the thumb; only clicking could set a value). Dragging
    # lives where it belongs -- the .pywebview-drag-region titlebar
    # -- through pywebview's drag-region path alone.
    window = webview.create_window(
        "ECHO 回声", url=str(index),
        js_api=bridge, width=1040, height=836,
        min_size=(880, 620), frameless=True, easy_drag=False,
        background_color="#dbe2eb")
    bridge._window = window
    _polish_and_hook(window)
    try:
        window.events.shown += lambda: _polish_and_hook(window)
    except Exception:
        pass
    # The native handle often only exists a moment after start, so
    # polish again on a delay -- a single early attempt that found
    # no handle used to leave the frame unmodernised for the whole
    # session with no sign of why.
    for delay in (1.5, 4.0):
        timer = threading.Timer(delay, _polish_and_hook, args=(window,))
        timer.daemon = True
        timer.start()
    webview.start()


if __name__ == "__main__":
    main()
